package api

var health = healthCheckState{Result: "I am alive"}
